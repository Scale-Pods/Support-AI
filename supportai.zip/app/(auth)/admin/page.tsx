'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/context/AuthContext'
import { useTheme } from '@/context/ThemeContext'
import BgOrbs from '@/components/BgOrbs'
import Badge, { statusBadge, priorityBadge, catBadge, confBadge } from '@/components/Badge'
import { createClient } from '@/lib/supabase'
import { N8N_BASE } from '@/lib/supabase'
import type { Ticket, Escalation, AuditLog, Product } from '@/lib/types'

type View = 'dashboard'|'tickets'|'escalations'|'products'|'ingest'|'audit'|'users'

function fmtDate(d: string) {
  if (!d) return '—'
  return new Date(d).toLocaleDateString('en-US', { month:'short', day:'numeric', hour:'2-digit', minute:'2-digit' })
}

const S: Record<string, React.CSSProperties> = {
  page:       { display:'flex', height:'100vh', overflow:'hidden', position:'relative', background:'var(--background)' },
  logoDot:    { width:8, height:8, borderRadius:'50%', background:'var(--primary)', boxShadow:'0 0 10px var(--primary)', flexShrink:0, WebkitTextFillColor:'initial' },
  sidebar:    { width:240, flexShrink:0, height:'100vh', background:'rgba(255,255,255,0.015)', borderRight:'1px solid rgba(255,255,255,0.06)', display:'flex', flexDirection:'column', padding:'1.5rem 0.875rem', position:'relative', zIndex:10 },
  sidebarLogo:{ fontFamily:'Inter,sans-serif', fontSize:'1.1rem', fontWeight:700, background:'linear-gradient(135deg,var(--primary),var(--chart-2))', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', display:'flex', alignItems:'center', gap:8, padding:'0 0.5rem', marginBottom:'0.25rem' },
  sLogo2:     { width:8, height:8, borderRadius:'50%', background:'var(--primary)', boxShadow:'0 0 12px rgba(96,165,250,0.5)', flexShrink:0, WebkitTextFillColor:'initial' },
  pill:       { display:'inline-flex', padding:'0.1875rem 0.625rem', borderRadius:100, fontSize:'0.6rem', fontWeight:600, textTransform:'uppercase', letterSpacing:'0.06em', background:'rgba(139,92,246,0.12)', color:'var(--chart-2)', border:'1px solid rgba(139,92,246,0.2)', margin:'0 0.5rem 1.5rem' },
  secLabel:   { fontSize:'0.6rem', fontWeight:600, letterSpacing:'0.1em', textTransform:'uppercase', color:'var(--muted-foreground)', padding:'0 0.5rem', marginBottom:'0.625rem' },
  navItem:    { display:'flex', alignItems:'center', gap:10, padding:'0.5rem 0.625rem', borderRadius:8, fontSize:'0.8375rem', fontWeight:500, color:'var(--muted-foreground)', cursor:'pointer', border:'1px solid transparent', transition:'all 0.2s ease', textDecoration:'none', marginBottom:2, position:'relative' },
  navActive:  { background:'rgba(139,92,246,0.08)', border:'1px solid rgba(139,92,246,0.15)', color:'var(--chart-2)' },
  tktBadge:   { marginLeft:'auto', minWidth:18, height:18, padding:'0 5px', background:'var(--destructive)', color:'#fff', borderRadius:100, fontSize:'0.6rem', fontWeight:700, display:'flex', alignItems:'center', justifyContent:'center' },
  userRow:    { marginTop:'auto', display:'flex', alignItems:'center', gap:10, padding:'0.75rem', background:'rgba(255,255,255,0.03)', border:'1px solid rgba(255,255,255,0.06)', borderRadius:12 },
  uAvatar:    { width:30, height:30, borderRadius:'50%', background:'linear-gradient(135deg,var(--chart-2),var(--primary))', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'0.7rem', fontWeight:700, flexShrink:0, color:'#fff' },
  main:       { flex:1, display:'flex', flexDirection:'column', overflow:'hidden', position:'relative', zIndex:1 },
  topbar:     { height:60, flexShrink:0, display:'flex', alignItems:'center', justifyContent:'space-between', padding:'0 1.75rem', borderBottom:'1px solid rgba(255,255,255,0.06)', background:'rgba(255,255,255,0.008)' },
  topbarTitle:{ fontFamily:'Inter,sans-serif', fontSize:'0.95rem', fontWeight:600, color:'var(--foreground)' },
  scroll:     { flex:1, overflowY:'auto', padding:'1.75rem' },
  vHeader:    { marginBottom:'1.75rem' },
  btnGhost:   { display:'inline-flex', alignItems:'center', gap:6, padding:'0.4375rem 0.875rem', borderRadius:8, fontSize:'0.8rem', fontWeight:600, cursor:'pointer', border:'1px solid rgba(255,255,255,0.08)', background:'rgba(255,255,255,0.03)', color:'var(--muted-foreground)', fontFamily:'Inter,sans-serif', transition:'all 0.2s ease' },
  btnPrimary: { display:'inline-flex', alignItems:'center', gap:6, padding:'0.5rem 1rem', borderRadius:8, fontSize:'0.8rem', fontWeight:600, cursor:'pointer', border:'none', background:'linear-gradient(135deg,var(--chart-2),var(--primary))', color:'#fff', fontFamily:'Inter,sans-serif', boxShadow:'0 4px 14px rgba(139,92,246,0.25)', transition:'all 0.2s ease' },
  btnSuccess: { display:'inline-flex', alignItems:'center', gap:6, padding:'0.3125rem 0.625rem', borderRadius:6, fontSize:'0.75rem', fontWeight:600, cursor:'pointer', border:'1px solid rgba(34,197,94,0.2)', background:'rgba(34,197,94,0.08)', color:'var(--chart-1)', fontFamily:'Inter,sans-serif' },
  btnDanger:  { display:'inline-flex', alignItems:'center', gap:6, padding:'0.3125rem 0.625rem', borderRadius:6, fontSize:'0.75rem', fontWeight:600, cursor:'pointer', border:'1px solid rgba(239,68,68,0.2)', background:'rgba(239,68,68,0.08)', color:'var(--destructive)', fontFamily:'Inter,sans-serif' },
  statsGrid:  { display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:'1rem', marginBottom:'1.75rem' },
  statCard:   { background:'rgba(255,255,255,0.025)', border:'1px solid rgba(255,255,255,0.06)', borderRadius:16, padding:'1.25rem', backdropFilter:'blur(16px)', transition:'all 0.2s ease' },
  statLabel:  { fontSize:'0.7rem', fontWeight:500, color:'var(--muted-foreground)', textTransform:'uppercase', letterSpacing:'0.08em' },
  statValue:  { fontFamily:'Inter,sans-serif', fontSize:'1.75rem', fontWeight:700, margin:'0.75rem 0 0.25rem', letterSpacing:'-0.02em' },
  dashGrid:   { display:'grid', gridTemplateColumns:'1fr 1fr', gap:'1.25rem' },
  card:       { background:'rgba(255,255,255,0.025)', border:'1px solid rgba(255,255,255,0.06)', borderRadius:16, overflow:'hidden' },
  cardHeader: { padding:'1rem 1.25rem', borderBottom:'1px solid rgba(255,255,255,0.06)', display:'flex', alignItems:'center', justifyContent:'space-between' },
  cardTitle:  { fontFamily:'Inter,sans-serif', fontSize:'0.9rem', fontWeight:600, color:'var(--foreground)' },
  table:      { width:'100%', borderCollapse:'collapse', fontSize:'0.8125rem' },
  th:         { textAlign:'left', padding:'0.75rem 0.875rem', color:'var(--muted-foreground)', fontWeight:600, fontSize:'0.65rem', textTransform:'uppercase', letterSpacing:'0.08em', borderBottom:'1px solid rgba(255,255,255,0.06)' },
  td:         { padding:'0.75rem 0.875rem', borderBottom:'1px solid rgba(255,255,255,0.03)', color:'var(--muted-foreground)', verticalAlign:'middle' },
  tktCard:    { background:'rgba(255,255,255,0.025)', border:'1px solid rgba(255,255,255,0.06)', borderRadius:12, padding:'1.125rem 1.25rem', marginBottom:10, cursor:'pointer', transition:'all 0.2s ease' },
  filterBtn:  { padding:'0.375rem 0.75rem', borderRadius:100, fontSize:'0.75rem', fontWeight:500, background:'rgba(255,255,255,0.03)', border:'1px solid rgba(255,255,255,0.06)', color:'var(--muted-foreground)', cursor:'pointer', transition:'all 0.2s ease' },
  filterActive:{ background:'rgba(139,92,246,0.1)', border:'1px solid rgba(139,92,246,0.2)', color:'var(--chart-2)' },
  prodCard:   { background:'rgba(255,255,255,0.025)', border:'1px solid rgba(255,255,255,0.06)', borderRadius:16, padding:'1.375rem', transition:'all 0.2s ease', cursor:'pointer' },
  ingestForm: { background:'rgba(255,255,255,0.025)', border:'1px solid rgba(255,255,255,0.06)', borderRadius:16, padding:'1.5rem' },
  formRow:    { display:'grid', gridTemplateColumns:'1fr 1fr', gap:'1rem' },
  fLabel:     { display:'block', fontSize:'0.8125rem', fontWeight:500, marginBottom:'0.5rem', color:'var(--muted-foreground)' },
  fInput:     { width:'100%', padding:'0.6875rem 0.875rem', background:'rgba(255,255,255,0.04)', border:'1px solid rgba(255,255,255,0.06)', borderRadius:8, color:'var(--foreground)', fontFamily:'Inter,sans-serif', fontSize:'0.875rem', outline:'none', marginBottom:'1.125rem', transition:'border-color 0.2s ease' },
  fSelect:    { width:'100%', padding:'0.6875rem 0.875rem', background:'rgba(255,255,255,0.04)', border:'1px solid rgba(255,255,255,0.06)', borderRadius:8, color:'var(--foreground)', fontFamily:'Inter,sans-serif', fontSize:'0.875rem', outline:'none', cursor:'pointer', marginBottom:'1.125rem' },
  fTextarea:  { width:'100%', padding:'0.75rem', minHeight:140, background:'rgba(255,255,255,0.04)', border:'1px solid rgba(255,255,255,0.06)', borderRadius:8, color:'var(--foreground)', fontFamily:'Inter,sans-serif', fontSize:'0.875rem', resize:'vertical', outline:'none' },
  progBar:    { height:4, background:'rgba(255,255,255,0.06)', borderRadius:4, overflow:'hidden', margin:'8px 0' },
  progFill:   { height:'100%', background:'linear-gradient(135deg,var(--chart-2),var(--primary))', borderRadius:4, transition:'width 0.4s ease' },
  modal:      { position:'fixed', inset:0, zIndex:150, background:'rgba(0,0,0,0.7)', backdropFilter:'blur(8px)', display:'flex', alignItems:'center', justifyContent:'center', padding:'1.5rem' },
  modalInner: { width:'100%', maxWidth:560, background:'var(--card)', border:'1px solid rgba(255,255,255,0.06)', borderRadius:20, padding:'1.75rem', maxHeight:'90vh', overflowY:'auto', boxShadow:'0 25px 50px -12px rgba(0,0,0,0.5)' },
  modalTitle: { fontFamily:'Inter,sans-serif', fontSize:'1.1rem', fontWeight:700, color:'var(--foreground)' },
  mFieldLabel:{ fontSize:'0.7rem', color:'var(--muted-foreground)', textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:6, fontWeight:600 },
  mFieldVal:  { fontSize:'0.875rem', lineHeight:1.6, color:'var(--foreground)' },
}

export default function AdminDashboard() {
  const { user, profile, token, loading, signIn, signOut } = useAuth()
  const { theme, toggleTheme } = useTheme()
  const router = useRouter()
  const [view, setView]         = useState<View>('dashboard')
  const [email, setEmail]       = useState('')
  const [password, setPassword] = useState('')
  const [authErr, setAuthErr]   = useState('')
  const [redirected, setRedirected] = useState(false)
  const [tickets, setTickets]   = useState<Ticket[]>([])
  const [filteredTickets, setFilteredTickets] = useState<Ticket[]>([])
  const [activeFilter, setActiveFilter]       = useState('all')
  const [escalations, setEscalations] = useState<Escalation[]>([])
  const [auditLogs, setAuditLogs]     = useState<AuditLog[]>([])
  const [products, setProducts]       = useState<Product[]>([])
  const [users, setUsers]             = useState<any[]>([])
  const [kbDocs, setKbDocs]           = useState<any[]>([])
  const [stats, setStats]             = useState({ conversations:0, openTickets:0, avgConf:0, escRate:0 })
  const [categories, setCategories]   = useState<[string,number][]>([])
  const [recentLogs, setRecentLogs]   = useState<AuditLog[]>([])
  const [openTicketCount, setOpenTicketCount] = useState(0)
  const [selectedTicket, setSelectedTicket]   = useState<Ticket|null>(null)
  const [modalTeam, setModalTeam]     = useState('')
  const [ingestProduct, setIngestProduct]   = useState('')
  const [ingestType, setIngestType]         = useState('faq')
  const [ingestTitle, setIngestTitle]       = useState('')
  const [ingestContent, setIngestContent]   = useState('')
  const [ingestProgress, setIngestProgress] = useState(0)
  const [ingestStatus, setIngestStatus]     = useState('')
  const [charCount, setCharCount]           = useState(0)
  const [uploadMode, setUploadMode]         = useState<'paste'|'file'>('paste')
  const [ingestFile, setIngestFile]         = useState<File|null>(null)
  const [showCreateProduct, setShowCreateProduct] = useState(false)
  const [newProductName, setNewProductName]       = useState('')
  const [newProductSlug, setNewProductSlug]       = useState('')
  const [createProductLoading, setCreateProductLoading] = useState(false)
  const supabase = createClient()

  useEffect(() => {
    if (!loading && user && profile?.is_admin) { loadDashboard(); loadProducts(); }
  }, [user, profile, loading])

  async function handleLogin() {
    setAuthErr('')
    const err = await signIn(email, password)
    if (err) { setAuthErr(err); return }
  }

  useEffect(() => {
    if (redirected) return
    if (!loading && user && profile && !profile.is_admin) {
      setRedirected(true)
      router.push('/client')
    }
  }, [loading, user, profile])

  async function loadDashboard() {
    const [logsRes, ticketsRes, sessionsRes] = await Promise.all([
      supabase.from('audit_logs').select('id,confidence,escalated,category,session_id,query,created_at').order('created_at', { ascending: false }).limit(200),
      supabase.from('tickets').select('id,status').order('created_at', { ascending: false }),
      supabase.from('public_sessions').select('id', { count: 'exact' })
    ])
    const logs      = logsRes.data || []
    const allTkts   = ticketsRes.data || []
    const totalSess = sessionsRes.count || 0
    const open      = allTkts.filter(t => t.status === 'open').length
    const avgConf   = logs.length ? logs.reduce((s:number,l:any)=>s+(l.confidence||0),0)/logs.length : 0
    const escalated = logs.filter((l:any) => l.escalated).length
    const escRate   = logs.length ? Math.round(escalated/logs.length*100) : 0
    setStats({ conversations: totalSess, openTickets: open, avgConf: Math.round(avgConf*100), escRate })
    setOpenTicketCount(open)
    const cats: Record<string,number> = {}
    logs.forEach((l:any) => { if(l.category) cats[l.category] = (cats[l.category]||0)+1 })
    setCategories(Object.entries(cats).sort((a,b)=>b[1]-a[1]).slice(0,6))
    setRecentLogs(logs.slice(0,8) as AuditLog[])
  }

  async function loadTickets() {
    const { data } = await supabase.from('tickets').select('*').order('created_at', { ascending: false })
    const t = (data || []) as Ticket[]
    setTickets(t); setFilteredTickets(t)
    setOpenTicketCount(t.filter(x=>x.status==='open').length)
  }

  function filterTickets(status: string) {
    setActiveFilter(status)
    setFilteredTickets(status === 'all' ? tickets : tickets.filter(t=>t.status===status))
  }

  async function updateTicketStatus(id: string, status: string) {
    await supabase.from('tickets').update({ status, ...(status==='resolved'?{resolved_at:new Date().toISOString()}:{}) }).eq('id', id)
    loadTickets(); setSelectedTicket(null)
  }

  async function saveTicketTeam() {
    if (!selectedTicket) return
    await supabase.from('tickets').update({ assigned_team: modalTeam }).eq('id', selectedTicket.id)
    setSelectedTicket(null); loadTickets()
  }

  async function loadEscalations() {
    const { data } = await supabase.from('escalations').select('*').order('created_at', { ascending: false }).limit(50)
    setEscalations((data || []) as Escalation[])
  }

  async function loadAuditLogs() {
    const { data } = await supabase.from('audit_logs').select('*').order('created_at', { ascending: false }).limit(100)
    setAuditLogs((data || []) as AuditLog[])
  }

  async function loadProducts() {
    const { data } = await supabase.from('products').select('*').order('created_at', { ascending: true })
    setProducts((data || []) as any)
  }

  async function loadUsers() {
  const { data } = await supabase.from('users').select('*').eq('role', 'client').order('created_at', { ascending: false })
  setUsers(data || [])
 }

  async function loadKBDocs() {
    const { data } = await supabase.from('knowledge_documents').select('*').order('created_at', { ascending: false }).limit(20)
    setKbDocs((data || []).map((d:any) => ({ ...d, _public: !d.product_id })))
  }

  async function toggleProduct(id: string, active: boolean) {
    await supabase.from('products').update({ is_active: active }).eq('id', id); loadProducts()
  }

  async function assignProduct(userId: string, productId: string) {
    await supabase.from('users').update({ product_id: productId || null }).eq('id', userId)
  }

  async function handleCreateProduct() {
    if (!newProductName.trim() || !newProductSlug.trim()) { alert('Name and slug are required.'); return }
    setCreateProductLoading(true)
    const slug = newProductSlug.trim().toLowerCase().replace(/\s+/g, '-')
    const res = await fetch('/api/products/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: newProductName.trim(), slug, created_by: user?.id }),
    })
    if (!res.ok) { const err = await res.json(); alert('Failed to create product: ' + (err.error || 'Unknown error')); setCreateProductLoading(false); return }
    setNewProductName(''); setNewProductSlug(''); setShowCreateProduct(false)
    setCreateProductLoading(false)
    loadProducts()
  }

  function isTextFile(file: File) {
    return /\.(txt|md|csv|json|xml|yaml|yml|log|env)$/i.test(file.name) || file.type.startsWith('text/')
  }

  function isPDF(file: File) {
    return /\.pdf$/i.test(file.name) || file.type === 'application/pdf'
  }

  async function extractPDFText(file: File): Promise<string> {
    const pdfjsLib = await import('pdfjs-dist')
    const worker = new Worker('/pdf.worker.min.mjs', { type: 'module' })
    pdfjsLib.GlobalWorkerOptions.workerPort = worker
    const buffer = await file.arrayBuffer()
    const pdf = await pdfjsLib.getDocument({ data: new Uint8Array(buffer) }).promise
    let text = ''
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i)
      const content = await page.getTextContent()
      text += content.items.map((item: any) => ('str' in item ? item.str : '')).join(' ') + '\n\n'
    }
    worker.terminate()
    return text.trim()
  }

  async function readFileContent(file: File): Promise<string> {
    if (isTextFile(file)) {
      return new Promise((resolve, reject) => {
        const reader = new FileReader()
        reader.onload = () => resolve(reader.result as string)
        reader.onerror = reject
        reader.readAsText(file)
      })
    }
    if (isPDF(file)) {
      return extractPDFText(file)
    }
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onload = () => {
        const base64 = (reader.result as string).split(',')[1]
        resolve(base64)
      }
      reader.onerror = reject
      reader.readAsDataURL(file)
    })
  }

  async function ingestDocument() {
    if (!ingestProduct || !ingestTitle) { alert('Please fill in all fields.'); return }
    if (uploadMode === 'paste' && !ingestContent) { alert('Please paste document content.'); return }
    if (uploadMode === 'file' && !ingestFile) { alert('Please select a file to upload.'); return }
    setIngestProgress(20); setIngestStatus('Sending to n8n…')
    try {
      let content = ingestContent
      let fileName: string|undefined
      if (uploadMode === 'file' && ingestFile) {
        content = await readFileContent(ingestFile)
        fileName = ingestFile.name
      }
      await fetch(`${N8N_BASE}/admin-ingest`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify({
          product_id: ingestProduct === '__public__' ? null : ingestProduct,
          source_type: ingestType, title: ingestTitle, content,
          is_public: ingestProduct === '__public__',
          ...(fileName ? { file_name: fileName, is_binary: !isTextFile(ingestFile!) && !isPDF(ingestFile!) } : {})
        })
      })
      setIngestProgress(100); setIngestStatus('✅ Ingested successfully!')
      setIngestTitle(''); setIngestContent(''); setCharCount(0); setIngestFile(null)
      setTimeout(() => { setIngestProgress(0); setIngestStatus('') }, 3000)
      loadKBDocs()
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e)
      setIngestProgress(100); setIngestStatus('❌ ' + msg)
    }
  }

  function switchView(v: View) {
    setView(v)
    if (v==='dashboard')   { loadDashboard(); loadProducts() }
    if (v==='tickets')     loadTickets()
    if (v==='escalations') loadEscalations()
    if (v==='audit')       loadAuditLogs()
    if (v==='users')       loadUsers()
    if (v==='ingest')      { loadKBDocs(); loadProducts() }
  }

  const catColors = ['var(--primary)','var(--chart-2)','var(--ring)','var(--chart-1)','#eab308','#f97316']
  const initials = (profile?.full_name || profile?.email || 'A').split(' ').map((w:string)=>w[0]).join('').substr(0,2).toUpperCase()

  if (loading) return (
    <div style={{ height:'100vh', display:'flex', alignItems:'center', justifyContent:'center', background:'var(--background)', color:'var(--muted-foreground)', flexDirection:'column', gap:12 }}>
      <div style={{ width:28, height:28, borderRadius:'50%', border:'3px solid rgba(255,255,255,0.06)', borderTopColor:'var(--primary)', animation:'spin 0.8s linear infinite' }} />
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      <span style={{ fontSize:'0.875rem', color:'var(--muted-foreground)' }}>Loading dashboard…</span>
    </div>
  )

  if (!user) return (
    <div style={{
      position:'fixed', inset:0, zIndex:200, background:'var(--background)',
      display:'flex', alignItems:'center', justifyContent:'center'
    }}>
      <BgOrbs />
      <div style={{
        width:'100%', maxWidth:420, background:'rgba(255,255,255,0.04)',
        border:'1px solid rgba(255,255,255,0.08)', borderRadius:20,
        padding:'2.5rem', backdropFilter:'blur(24px)', position:'relative', zIndex:1
      }}>
        <div style={{
          fontFamily:'Inter,sans-serif', fontSize:'1.25rem', fontWeight:700,
          background:'linear-gradient(135deg,var(--primary),var(--ring))', WebkitBackgroundClip:'text',
          WebkitTextFillColor:'transparent', display:'flex', alignItems:'center', gap:8, marginBottom:'2rem'
        }}>
          <div style={{
            width:8, height:8, borderRadius:'50%', background:'var(--primary)',
            boxShadow:'0 0 10px var(--primary)', flexShrink:0, WebkitTextFillColor:'initial'
          }} />
          <span>SupportAI</span>
        </div>
        <div style={{
          display:'inline-flex', alignItems:'center', padding:'0.25rem 0.75rem',
          borderRadius:100, fontSize:'0.75rem', fontWeight:600, textTransform:'uppercase',
          letterSpacing:'0.05em', background:'rgba(139,92,246,0.1)', color:'var(--chart-2)',
          border:'1px solid rgba(139,92,246,0.2)', marginBottom:'1rem'
        }}>
          ⚙️ Admin Access
        </div>
        <h1 style={{
          fontFamily:'Inter,sans-serif', fontSize:'1.5rem', fontWeight:700, marginBottom:'0.5rem'
        }}>Admin Dashboard</h1>
        <p style={{ color:'var(--muted-foreground)', fontSize:'0.875rem', marginBottom:'2rem' }}>
          Sign in with your admin credentials.
        </p>
        <label style={{ display:'block', fontSize:'0.8125rem', fontWeight:500, marginBottom:'0.5rem', color:'var(--muted-foreground)' }}>
          Email
        </label>
        <input
          type="email"
          style={{
            width:'100%', padding:'0.75rem 1rem', background:'rgba(255,255,255,0.05)',
            border:'1px solid rgba(255,255,255,0.08)', borderRadius:8, color:'var(--foreground)',
            fontFamily:'Inter,sans-serif', fontSize:'0.9rem', outline:'none', marginBottom:'1.25rem'
          }}
          value={email} onChange={e=>setEmail(e.target.value)} placeholder="admin@company.com"
        />
        <label style={{ display:'block', fontSize:'0.8125rem', fontWeight:500, marginBottom:'0.5rem', color:'var(--muted-foreground)' }}>
          Password
        </label>
        <input
          type="password"
          style={{
            width:'100%', padding:'0.75rem 1rem', background:'rgba(255,255,255,0.05)',
            border:'1px solid rgba(255,255,255,0.08)', borderRadius:8, color:'var(--foreground)',
            fontFamily:'Inter,sans-serif', fontSize:'0.9rem', outline:'none', marginBottom:'1.25rem'
          }}
          value={password} onChange={e=>setPassword(e.target.value)}
          placeholder="••••••••" onKeyDown={e=>e.key==='Enter'&&handleLogin()}
        />
        <button
          style={{
            width:'100%', padding:'0.875rem', background:'linear-gradient(135deg,var(--chart-2),var(--primary))',
            border:'none', borderRadius:8, color:'#fff', fontFamily:'Inter,sans-serif',
            fontSize:'0.9375rem', fontWeight:600, cursor:'pointer',
            boxShadow:'0 0 20px rgba(139,92,246,0.3)'
          }}
          onClick={handleLogin}
        >
          Access Dashboard →
        </button>
        {authErr && (
          <div style={{
            color:'var(--destructive)', fontSize:'0.8125rem', textAlign:'center',
            marginTop:'1rem'
          }}>
            {authErr}
          </div>
        )}
      </div>
    </div>
  )

  const icons: Record<string, React.ReactNode> = {
    dashboard: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/></svg>,
    audit: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>,
    tickets: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"/><path d="M13 5v2"/><path d="M13 17v2"/><path d="M13 11v2"/></svg>,
    escalations: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>,
    products: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>,
    ingest: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>,
    users: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>,
    home: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>,
    user: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>,
    chat: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>,
    target: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>,
    alert: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>,
    box: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>,
  }

  const navItems: [View, string, string][] = [
    ['dashboard','dashboard','Dashboard'],['audit','audit','Audit Logs'],
    ['tickets','tickets','Tickets'],['escalations','escalations','Escalations'],
    ['products','products','Products'],['ingest','ingest','KB Ingestion'],['users','users','Client Users']
  ]

  return (
    <><div style={S.page}>
      <BgOrbs />

      {/* TICKET MODAL */}
      {selectedTicket && (
        <div style={S.modal} onClick={e=>e.target===e.currentTarget&&setSelectedTicket(null)}>
          <div style={S.modalInner}>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:'1.5rem' }}>
              <div style={S.modalTitle}>Ticket #{selectedTicket.id.substr(0,8)}</div>
              <div style={{ width:30, height:30, borderRadius:'50%', background:'rgba(255,255,255,0.04)', border:'1px solid rgba(255,255,255,0.08)', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center' }} onClick={()=>setSelectedTicket(null)}>✕</div>
            </div>
            {[['Title',selectedTicket.title],['Description',selectedTicket.description||'—']].map(([l,v])=>(
              <div key={l} style={{ marginBottom:'1rem' }}>
                <div style={S.mFieldLabel}>{l}</div>
                <div style={S.mFieldVal}>{v}</div>
              </div>
            ))}
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'1rem', marginBottom:'1rem' }}>
              <div><div style={S.mFieldLabel}>Status</div><Badge variant={statusBadge(selectedTicket.status)}>{selectedTicket.status}</Badge></div>
              <div><div style={S.mFieldLabel}>Priority</div><Badge variant={priorityBadge(selectedTicket.priority)}>{selectedTicket.priority}</Badge></div>
              <div><div style={S.mFieldLabel}>Team</div><div style={S.mFieldVal}>{selectedTicket.assigned_team||'—'}</div></div>
              <div><div style={S.mFieldLabel}>Admin Only</div><Badge variant="purple">Hidden from client</Badge></div>
            </div>
            <div style={{ marginBottom:'1rem' }}>
              <div style={S.mFieldLabel}>Update Team</div>
              <select style={{ ...S.fSelect, marginTop:6, marginBottom:0 }} value={modalTeam} onChange={e=>setModalTeam(e.target.value)}>
                {['engineering','product','ops','finance','support'].map(t=><option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div style={{ display:'flex', gap:12, marginTop:'1.5rem' }}>
              <button style={S.btnPrimary} onClick={saveTicketTeam}>Save Team</button>
              <button style={S.btnSuccess} onClick={()=>updateTicketStatus(selectedTicket.id,'resolved')}>Mark Resolved</button>
              <button style={S.btnGhost} onClick={()=>setSelectedTicket(null)}>Close</button>
            </div>
          </div>
        </div>
      )}

      {/* SIDEBAR */}
      <div style={S.sidebar}>
        <div style={S.sidebarLogo}><div style={S.sLogo2} /><span>SupportAI</span></div>
        <div style={S.pill}>Admin Portal</div>
        {[['Overview',navItems.slice(0,2)],['Support',navItems.slice(2,4)],['Configuration',navItems.slice(4)]].map(([sec, items]:any)=>(
          <div key={sec} style={{ marginBottom:'1.5rem' }}>
            <div style={S.secLabel}>{sec}</div>
            {items.map(([v,iconKey,label]:any)=>(
              <div key={v} style={{ ...S.navItem, ...(view===v?S.navActive:{}) }} onClick={()=>switchView(v)}>
                <span style={{ flexShrink:0, display:'flex', color:'currentColor' }}>{icons[iconKey]}</span>{label}
                {v==='tickets' && openTicketCount > 0 && <div style={S.tktBadge}>{openTicketCount}</div>}
              </div>
            ))}
          </div>
        ))}
        <div style={{ marginBottom:'1.5rem' }}>
          <div style={S.secLabel}>Navigation</div>
          <Link href="/"       style={{ ...S.navItem }}><span style={{ flexShrink:0, display:'flex', color:'currentColor' }}>{icons.home}</span>Landing Page</Link>
          <div style={{ ...S.navItem }} onClick={signOut}><span style={{ flexShrink:0, display:'flex', color:'currentColor' }}>{icons.user}</span>Client Portal</div>
        </div>
        <div style={S.userRow}>
          <div style={S.uAvatar}>{initials}</div>
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ fontSize:'0.8rem', fontWeight:600, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{profile?.full_name||profile?.email}</div>
            <div style={{ fontSize:'0.7rem', color:'var(--chart-2)' }}>Administrator</div>
          </div>
          <div style={{ display:'flex', gap:6 }}>
            <div style={{ fontSize:'1rem', color:'var(--muted-foreground)', cursor:'pointer' }} onClick={toggleTheme}>{theme==='dark'?'☀️':'🌙'}</div>
            <div style={{ fontSize:'0.75rem', color:'var(--muted-foreground)', cursor:'pointer' }} onClick={signOut}>⏏</div>
          </div>
        </div>
      </div>

      {/* MAIN */}
      <div style={S.main}>

        {/* DASHBOARD */}
        {view==='dashboard' && <>
          <div style={S.topbar}>
            <div style={S.topbarTitle}>Overview</div>
            <div style={{ display:'flex', gap:8 }}>
              <button style={S.btnGhost} onClick={loadDashboard}><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ marginRight:4 }}><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>Refresh</button>
              <button style={S.btnPrimary} onClick={()=>switchView('ingest')}>+ Ingest</button>
            </div>
          </div>
          <div style={S.scroll}>
            <div style={S.statsGrid}>
              {[
                { label:'Total Conversations', icon:'chat', value: stats.conversations, sub:'All time' },
                { label:'Open Tickets',        icon:'tickets', value: stats.openTickets,  sub:'Needs attention', red: stats.openTickets > 0 },
                { label:'Avg Confidence',      icon:'target', value: stats.avgConf+'%',  sub: stats.avgConf > 65 ? '↑ Above threshold' : '↓ Below threshold' },
                { label:'Escalation Rate',     icon:'alert', value: stats.escRate+'%',  sub: stats.escRate < 15 ? '↓ Under control' : '↑ High rate' },
              ].map(s=>(
                <div key={s.label} style={S.statCard}>
                  <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                    <span style={S.statLabel}>{s.label}</span><span style={{ flexShrink:0, display:'flex', color:'var(--muted-foreground)', width:18, height:18 }}>{icons[s.icon]}</span>
                  </div>
                  <div style={{ ...S.statValue, color: (s as any).red ? 'var(--destructive)' : 'var(--foreground)' }}>{s.value}</div>
                  <div style={{ fontSize:'0.75rem', color: stats.avgConf>65||stats.escRate<15 ? 'var(--chart-1)' : 'var(--muted-foreground)' }}>{s.sub}</div>
                </div>
              ))}
            </div>
            <div style={S.dashGrid}>
              <div style={S.card}>
                <div style={S.cardHeader}><span style={S.cardTitle}>Query Categories</span><Badge variant="blue">Last 200</Badge></div>
                <div style={{ padding:'1.25rem', display:'flex', flexDirection:'column', gap:12 }}>
                  {categories.length === 0 ? <div style={{ color:'var(--muted-foreground)', fontSize:'0.8125rem' }}>No data yet</div> :
                    categories.map(([cat,cnt],i)=>{
                      const max = categories[0][1]
                      return <div key={cat} style={{ display:'flex', alignItems:'center', gap:12, fontSize:'0.8125rem' }}>
                        <span style={{ width:80, color:'var(--muted-foreground)', flexShrink:0 }}>{cat}</span>
                        <div style={{ flex:1, height:6, background:'rgba(255,255,255,0.06)', borderRadius:3, overflow:'hidden' }}>
                          <div style={{ height:'100%', width:`${cnt/max*100}%`, background:catColors[i]||catColors[0], borderRadius:3 }} />
                        </div>
                        <span style={{ width:30, textAlign:'right', color:'var(--muted-foreground)' }}>{cnt}</span>
                      </div>
                    })
                  }
                </div>
              </div>
              <div style={S.card}>
                <div style={S.cardHeader}><span style={S.cardTitle}>AI Confidence Score</span></div>
                <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', padding:'1.5rem' }}>
                  <svg width={120} height={120} viewBox="0 0 120 120">
                    <circle cx={60} cy={60} r={50} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={10} />
                    <circle cx={60} cy={60} r={50} fill="none" stroke="url(#adminGrad)" strokeWidth={10}
                      strokeDasharray={314} strokeDashoffset={314 - (314 * stats.avgConf / 100)}
                      strokeLinecap="round" transform="rotate(-90 60 60)" style={{ transition:'stroke-dashoffset 0.8s ease' }} />
                    <defs><linearGradient id="adminGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="var(--chart-2)" /><stop offset="100%" stopColor="var(--primary)" />
                    </linearGradient></defs>
                  </svg>
                  <div style={{ fontFamily:'Inter,sans-serif', fontSize:'1.75rem', fontWeight:700, marginTop:8 }}>{stats.avgConf}%</div>
                  <div style={{ fontSize:'0.75rem', color:'var(--muted-foreground)' }}>Average confidence</div>
                </div>
              </div>
              <div style={{ ...S.card, gridColumn:'1/-1' }}>
                <div style={S.cardHeader}><span style={S.cardTitle}>Recent Activity</span><button style={S.btnGhost} onClick={()=>switchView('audit')}>View All</button></div>
                <table style={S.table}>
                  <thead><tr>{['Session','Query','Category','Confidence','Escalated','Time'].map(h=><th key={h} style={S.th}>{h}</th>)}</tr></thead>
                  <tbody>
                    {recentLogs.length === 0
                      ? <tr key="empty"><td colSpan={6} style={{ ...S.td, textAlign:'center', padding:'2rem', color:'var(--muted-foreground)' }}>No activity yet</td></tr>
                      : recentLogs.map(l=>(
                        <tr key={l.id}>
                          <td style={{ ...S.td, fontFamily:'monospace', fontSize:'0.75rem', color:'var(--foreground)' }}>{l.session_id?.substr(0,8)}…</td>
                          <td style={S.td}>{l.query?.slice(0,60)}{l.query?.length>60?'…':''}</td>
                          <td style={S.td}>{l.category?<Badge variant={catBadge(l.category)}>{l.category}</Badge>:'—'}</td>
                          <td style={S.td}>{l.confidence!=null?<Badge variant={confBadge(l.confidence)}>{Math.round(l.confidence*100)}%</Badge>:'—'}</td>
                          <td style={S.td}>{l.escalated?<Badge variant="red">Yes</Badge>:<Badge variant="green">No</Badge>}</td>
                          <td style={S.td}>{fmtDate(l.created_at)}</td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </>}

        {/* TICKETS */}
        {view==='tickets' && <>
          <div style={S.topbar}>
            <div style={S.topbarTitle}>Tickets — Admin Only</div>
            <button style={S.btnGhost} onClick={loadTickets}>↻ Refresh</button>
          </div>
          <div style={S.scroll}>
            <h2 style={{ fontFamily:'Inter,sans-serif', fontSize:'1.375rem', fontWeight:700, marginBottom:'0.25rem' }}>Support Tickets</h2>
            <p style={{ color:'var(--muted-foreground)', fontSize:'0.875rem', marginBottom:'1.25rem' }}>Admin-only. Clients cannot view these regardless of access level.</p>
            <div style={{ display:'flex', gap:8, flexWrap:'wrap', marginBottom:'1.25rem' }}>
              {['all','open','in_progress','resolved','closed'].map(f=>(
                <button key={f} style={{ ...S.filterBtn, ...(activeFilter===f?S.filterActive:{}) }} onClick={()=>filterTickets(f)}>{f}</button>
              ))}
            </div>
            {filteredTickets.length === 0
              ? <div style={{ color:'var(--muted-foreground)', textAlign:'center', padding:'3rem', fontSize:'0.875rem' }}>No tickets found.</div>
              : filteredTickets.map(t=>(
                <div key={t.id} style={S.tktCard} onClick={()=>{setSelectedTicket(t);setModalTeam(t.assigned_team||'engineering')}}>
                  <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:10 }}>
                    <span style={{ fontFamily:'monospace', fontSize:'0.7rem', color:'var(--muted-foreground)' }}>#{t.id.substr(0,8)}</span>
                    <span style={{ fontWeight:600, fontSize:'0.875rem', flex:1 }}>{t.title}</span>
                    <Badge variant={statusBadge(t.status)}>{t.status}</Badge>
                    <Badge variant={priorityBadge(t.priority)}>{t.priority||'medium'}</Badge>
                  </div>
                  <div style={{ fontSize:'0.8125rem', color:'var(--muted-foreground)', lineHeight:1.55, marginBottom:10 }}>{t.description?.slice(0,180)}{t.description?.length>180?'…':''}</div>
                  <div style={{ display:'flex', alignItems:'center', gap:12, flexWrap:'wrap' }}>
                    <span style={{ fontSize:'0.75rem', color:'var(--muted-foreground)' }}>📅 {fmtDate(t.created_at)}</span>
                    <span style={{ fontSize:'0.75rem', color:'var(--muted-foreground)' }}>🏢 {t.assigned_team||'unassigned'}</span>
                    <div style={{ display:'flex', gap:8, marginLeft:'auto' }} onClick={e=>e.stopPropagation()}>
                      {t.status!=='in_progress' && <button style={S.btnGhost} onClick={()=>updateTicketStatus(t.id,'in_progress')}>Start</button>}
                      {t.status!=='resolved'    && <button style={S.btnSuccess} onClick={()=>updateTicketStatus(t.id,'resolved')}>Resolve</button>}
                      {t.status!=='closed'      && <button style={S.btnDanger}  onClick={()=>updateTicketStatus(t.id,'closed')}>Close</button>}
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </>}

        {/* ESCALATIONS */}
        {view==='escalations' && <>
          <div style={S.topbar}><div style={S.topbarTitle}>Escalations</div></div>
          <div style={S.scroll}>
            <h2 style={{ fontFamily:'Inter,sans-serif', fontSize:'1.375rem', fontWeight:700, marginBottom:'0.25rem' }}>Escalation Log</h2>
            <p style={{ color:'var(--muted-foreground)', fontSize:'0.875rem', marginBottom:'1.5rem' }}>System-triggered and user-requested escalations.</p>
            <div style={S.card}>
              <table style={S.table}>
                <thead><tr>{['Ticket ID','Reason','Triggered By','Confidence','Routed To','Time'].map(h=><th key={h} style={S.th}>{h}</th>)}</tr></thead>
                <tbody>
                  {escalations.length===0
                    ? <tr key="empty-escalations"><td colSpan={6} style={{ ...S.td, textAlign:'center', padding:'2rem', color:'var(--muted-foreground)' }}>No escalations yet</td></tr>
                    : escalations.map(e=>(
                      <tr key={e.id}>
                        <td style={{ ...S.td, fontFamily:'monospace', fontSize:'0.75rem', color:'var(--foreground)' }}>{e.ticket_id?.substr(0,8)}…</td>
                        <td style={S.td}><Badge variant={e.reason==='low_confidence'?'yellow':'red'}>{e.reason||'—'}</Badge></td>
                        <td style={S.td}><Badge variant={e.triggered_by==='system'?'blue':'purple'}>{e.triggered_by||'—'}</Badge></td>
                        <td style={S.td}>{e.confidence_at_trigger!=null?Math.round(e.confidence_at_trigger*100)+'%':'—'}</td>
                        <td style={S.td}>{e.routed_to||'—'}</td>
                        <td style={S.td}>{fmtDate(e.created_at)}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </>}

        {/* PRODUCTS */}
        {view==='products' && <>
          <div style={S.topbar}>
            <div style={S.topbarTitle}>Products</div>
            <button style={S.btnPrimary} onClick={()=>setShowCreateProduct(true)}>+ Create Product</button>
          </div>
          <div style={S.scroll}>
            <h2 style={{ fontFamily:'Inter,sans-serif', fontSize:'1.375rem', fontWeight:700, marginBottom:'0.25rem' }}>Product Management</h2>
            <p style={{ color:'var(--muted-foreground)', fontSize:'0.875rem', marginBottom:'1.5rem' }}>Each product has its own isolated knowledge base.</p>
            <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(280px,1fr))', gap:'1rem' }}>
              {products.map(p=>(
                <div key={p.id} style={S.prodCard}>
                  <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:'1rem' }}>
                    <div style={{ width:40, height:40, borderRadius:8, background:'linear-gradient(135deg,rgba(59,130,246,0.2),rgba(139,92,246,0.2))', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--primary)' }}>{icons.box}</div>
                    <Badge variant={p.is_active?'green':'gray'}>{p.is_active?'Active':'Inactive'}</Badge>
                  </div>
                  <div style={{ fontFamily:'Inter,sans-serif', fontSize:'1rem', fontWeight:600, marginBottom:4 }}>{p.name}</div>
                  <div style={{ fontFamily:'monospace', fontSize:'0.7rem', color:'var(--muted-foreground)', marginBottom:'0.25rem' }}>/{p.slug}</div>
                  <div style={{ fontSize:'0.7rem', color:'var(--muted-foreground)', marginBottom:'1rem' }}>Created by {p.creator?.full_name || p.creator?.email || '—'}</div>
                  <div style={{ display:'flex', gap:8 }}>
                    <button style={S.btnGhost} onClick={()=>switchView('ingest')}>+ Add Docs</button>
                    <button style={S.btnDanger} onClick={()=>toggleProduct(p.id,!p.is_active)}>{p.is_active?'Deactivate':'Activate'}</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>}

        {/* INGEST */}
        {view==='ingest' && <>
          <div style={S.topbar}><div style={S.topbarTitle}>Knowledge Base Ingestion</div></div>
          <div style={S.scroll}>
            <h2 style={{ fontFamily:'Inter,sans-serif', fontSize:'1.375rem', fontWeight:700, marginBottom:'0.25rem' }}>Ingest Documents</h2>
            <p style={{ color:'var(--muted-foreground)', fontSize:'0.875rem', marginBottom:'1.5rem' }}>Upload FAQs, SOPs, and docs. n8n chunks, embeds, and stores in pgvector. Select a product to scope to that product's KB, or choose <strong>Public Knowledge Base</strong> to make docs available to all users.</p>
            <div style={S.ingestForm}>
              <div style={S.formRow}>
                <div>
                  <label style={S.fLabel}>Target Product *</label>
                  <select style={S.fSelect} value={ingestProduct} onChange={e=>setIngestProduct(e.target.value)}>
                    <option value="" style={{ background:'var(--card)', color:'var(--muted-foreground)' }}>Select a product…</option>
                    <option value="__public__" style={{ background:'var(--card)', color:'var(--foreground)' }}>🌐 Public Knowledge Base</option>
                    {products.map(p=><option key={p.id} value={p.id} style={{ background:'var(--card)', color:'var(--foreground)' }}>{p.name}</option>)}
                  </select>
                </div>
                <div>
                  <label style={S.fLabel}>Document Type</label>
                  <select style={S.fSelect} value={ingestType} onChange={e=>setIngestType(e.target.value)}>
                    {[['faq','FAQ'],['sop','SOP / Process Guide'],['doc','Product Documentation'],['ticket_resolution','Resolved Ticket']].map(([v,l])=><option key={v} value={v} style={{ background:'var(--card)', color:'var(--foreground)' }}>{l}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label style={S.fLabel}>Document Title *</label>
                <input type="text" style={S.fInput} value={ingestTitle} onChange={e=>setIngestTitle(e.target.value)} placeholder="e.g. Getting Started Guide" />
              </div>
              <div style={{ display:'flex', gap:'0.75rem', marginBottom:'1rem' }}>
                <button style={{ ...S.filterBtn, ...(uploadMode==='paste'?S.filterActive:{}) }} onClick={()=>setUploadMode('paste')}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ marginRight:6 }}><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/></svg>
                  Paste Text
                </button>
                <button style={{ ...S.filterBtn, ...(uploadMode==='file'?S.filterActive:{}) }} onClick={()=>setUploadMode('file')}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ marginRight:6 }}><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/></svg>
                  Upload File
                </button>
              </div>
              {uploadMode === 'paste' ? (
                <div>
                  <label style={S.fLabel}>Document Content *</label>
                  <textarea style={S.fTextarea} value={ingestContent} onChange={e=>{setIngestContent(e.target.value);setCharCount(e.target.value.length)}} placeholder="Paste the full document content here. n8n will chunk it into 800-character segments." />
                  <div style={{ fontSize:'0.75rem', color:'var(--muted-foreground)', marginTop:6 }}>{charCount} characters</div>
                </div>
              ) : (
                <div>
                  <label style={S.fLabel}>Upload File *</label>
                  <div style={{ background:'rgba(255,255,255,0.03)', border:'1px dashed rgba(255,255,255,0.15)', borderRadius:12, padding:'2rem 1.5rem', textAlign:'center', cursor:'pointer' }}
                    onClick={() => document.getElementById('file-input')?.click()}
                    onDragOver={e => e.preventDefault()}
                    onDrop={e => { e.preventDefault(); const f = e.dataTransfer.files[0]; if (f) setIngestFile(f) }}
                  >
                    {ingestFile ? (
                      <div>
                        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ marginBottom:8 }}><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/></svg>
                        <div style={{ fontSize:'0.875rem', fontWeight:600, marginBottom:4 }}>{ingestFile.name}</div>
                        <div style={{ fontSize:'0.75rem', color:'var(--muted-foreground)' }}>{(ingestFile.size / 1024).toFixed(1)} KB · {ingestFile.type || 'Unknown type'}</div>
                        <button style={{ ...S.btnGhost, marginTop:8 }} onClick={(e) => { e.stopPropagation(); setIngestFile(null) }}>Remove</button>
                      </div>
                    ) : (
                      <div>
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="var(--muted-foreground)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" style={{ marginBottom:12 }}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                        <div style={{ fontSize:'0.875rem', color:'var(--muted-foreground)', marginBottom:4 }}>Drop a file here or click to browse</div>
                        <div style={{ fontSize:'0.75rem', color:'var(--muted-foreground)' }}>PDF, DOCX, TXT, MD — up to 10 MB</div>
                      </div>
                    )}
                  </div>
                  <input id="file-input" type="file" accept=".pdf,.docx,.doc,.txt,.md,.csv,.json" style={{ display:'none' }} onChange={e => { const f = e.target.files?.[0]; if (f) { setIngestFile(f); if (f.size > 10*1024*1024) { alert('File exceeds 10 MB limit.'); setIngestFile(null) } } }} />
                </div>
              )}
              <button style={{ ...S.btnPrimary, padding:'0.75rem 1.5rem', fontSize:'0.875rem', marginTop:'1rem' }} onClick={ingestDocument}>
                {uploadMode === 'file' ? (
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ marginRight:6 }}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                ) : (
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ marginRight:6 }}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                )}
                {uploadMode === 'file' ? 'Upload & Process File' : 'Ingest & Embed Document'}
              </button>
              {ingestProgress > 0 && (
                <div style={{ marginTop:'1rem', background:'rgba(255,255,255,0.03)', border:'1px solid rgba(255,255,255,0.08)', borderRadius:12, padding:'1rem' }}>
                  <div style={{ fontSize:'0.875rem', fontWeight:600, marginBottom:6 }}>{ingestStatus}</div>
                  <div style={S.progBar}><div style={{ ...S.progFill, width:`${ingestProgress}%` }} /></div>
                </div>
              )}
            </div>
            <div style={{ marginTop:'2rem' }}>
              <div style={S.card}>
                <div style={S.cardHeader}><span style={S.cardTitle}>Recent KB Documents</span></div>
                <table style={S.table}>
                  <thead><tr>{['Title','Product','Type','Status','Added'].map(h=><th key={h} style={S.th}>{h}</th>)}</tr></thead>
                  <tbody>
                    {kbDocs.length===0
                      ? <tr key="empty-docs"><td colSpan={5} style={{ ...S.td, textAlign:'center', padding:'2rem', color:'var(--muted-foreground)' }}>No documents yet</td></tr>
                      : kbDocs.map((d:any,i:number)=>(
                        <tr key={i}>
                          <td style={{ ...S.td, color:'var(--foreground)' }}>{d.title||'—'}</td>
                          <td style={S.td}>{d._public ? <Badge variant="cyan">Public KB</Badge> : (d.products?.name||'—')}</td>
                          <td style={S.td}><Badge variant="blue">{d.source_type||'—'}</Badge></td>
                          <td style={S.td}><Badge variant={d.status==='active'?'green':'gray'}>{d.status}</Badge></td>
                          <td style={S.td}>{fmtDate(d.created_at)}</td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </>}

        {/* AUDIT */}
        {view==='audit' && <>
          <div style={S.topbar}>
            <div style={S.topbarTitle}>Audit Logs</div>
            <button style={S.btnGhost} onClick={loadAuditLogs}>↻ Refresh</button>
          </div>
          <div style={S.scroll}>
            <h2 style={{ fontFamily:'Inter,sans-serif', fontSize:'1.375rem', fontWeight:700, marginBottom:'0.25rem' }}>Full Audit Trail</h2>
            <p style={{ color:'var(--muted-foreground)', fontSize:'0.875rem', marginBottom:'1.5rem' }}>Every interaction, PII-redacted. Query, response, confidence, category, sentiment, escalation status.</p>
            <div style={S.card}>
              <table style={S.table}>
                <thead><tr>{['User','Query','Category','Confidence','Sentiment','Escalated','Time'].map(h=><th key={h} style={S.th}>{h}</th>)}</tr></thead>
                <tbody>
                  {auditLogs.length===0
                    ? <tr key="empty-logs"><td colSpan={7} style={{ ...S.td, textAlign:'center', padding:'2rem', color:'var(--muted-foreground)' }}>No logs yet</td></tr>
                    : auditLogs.map(l=>(
                      <tr key={l.id}>
                        <td style={{ ...S.td, fontFamily:'monospace', fontSize:'0.75rem', color:'var(--foreground)' }}>{l.user_id?.substr(0,8)}</td>
                        <td style={S.td}>{l.query?.slice(0,60)}{l.query?.length>60?'…':''}</td>
                        <td style={S.td}>{l.category?<Badge variant={catBadge(l.category)}>{l.category}</Badge>:'—'}</td>
                        <td style={S.td}>{l.confidence!=null?<Badge variant={confBadge(l.confidence)}>{Math.round(l.confidence*100)}%</Badge>:'—'}</td>
                        <td style={S.td}>{l.sentiment||'—'}</td>
                        <td style={S.td}>{l.escalated?<Badge variant="red">Yes</Badge>:<Badge variant="green">No</Badge>}</td>
                        <td style={S.td}>{fmtDate(l.created_at)}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </>}

        {/* USERS */}
        {view==='users' && <>
          <div style={S.topbar}><div style={S.topbarTitle}>Client Users</div></div>
          <div style={S.scroll}>
            <h2 style={{ fontFamily:'Inter,sans-serif', fontSize:'1.375rem', fontWeight:700, marginBottom:'0.25rem' }}>Client Management</h2>
            <p style={{ color:'var(--muted-foreground)', fontSize:'0.875rem', marginBottom:'1.5rem' }}>Assign clients to products. Each client's RAG is scoped to their assigned product only.</p>
            <div style={S.card}>
              <table style={S.table}>
                <thead><tr>{['Name','Email','Product','Role','Created','Assign Product'].map(h=><th key={h} style={S.th}>{h}</th>)}</tr></thead>
                <tbody>
                  {users.length===0
                    ? <tr key="empty-users"><td colSpan={6} style={{ ...S.td, textAlign:'center', padding:'2rem', color:'var(--muted-foreground)' }}>No users yet</td></tr>
                    : users.map(u=>(
                      <tr key={u.id}>
                        <td style={{ ...S.td, color:'var(--foreground)' }}>{u.full_name||'—'}</td>
                        <td style={S.td}>{u.email||'—'}</td>
                        <td style={S.td}>{(u.products as any)?.name||<span style={{color:'var(--muted-foreground)'}}>Unassigned</span>}</td>
                        <td style={S.td}><Badge variant={u.is_admin?'purple':'blue'}>{u.role||'client'}</Badge></td>
                        <td style={S.td}>{fmtDate(u.created_at)}</td>
                        <td style={S.td}>
                          <select style={{ padding:'0.25rem 0.5rem', background:'rgba(255,255,255,0.05)', border:'1px solid rgba(255,255,255,0.08)', borderRadius:6, color:'var(--foreground)', fontSize:'0.75rem', cursor:'pointer' }} defaultValue={u.product_id||''} onChange={e=>assignProduct(u.id,e.target.value)}>
                            <option value="" style={{ background:'var(--card)', color:'var(--muted-foreground)' }}>No product</option>
                            {products.map(p=><option key={p.id} value={p.id} style={{ background:'var(--card)', color:'var(--foreground)' }}>{p.name}</option>)}
                          </select>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </>}

      </div>
    </div>
    {/* CREATE PRODUCT MODAL */}
    {showCreateProduct && (
      <div style={S.modal} onClick={e=>e.target===e.currentTarget&&setShowCreateProduct(false)}>
        <div style={S.modalInner}>
          <div style={S.modalTitle}>Create Product</div>
          <p style={{ color:'var(--muted-foreground)', fontSize:'0.875rem', marginBottom:'1.5rem', marginTop:'0.375rem' }}>Add a new product with its own isolated knowledge base.</p>
          <label style={S.fLabel}>Product Name</label>
          <input type="text" style={S.fInput} value={newProductName} onChange={e=>{const v=e.target.value;setNewProductName(v);setNewProductSlug(v.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,''))}} placeholder="e.g. Acme Dashboard" />
          <label style={S.fLabel}>Slug</label>
          <input type="text" style={S.fInput} value={newProductSlug} onChange={e=>setNewProductSlug(e.target.value.toLowerCase().replace(/\s+/g,'-'))} placeholder="e.g. acme-dashboard" />
          <div style={{ display:'flex', gap:8, justifyContent:'flex-end', marginTop:'1.5rem' }}>
            <button style={S.btnGhost} onClick={()=>setShowCreateProduct(false)}>Cancel</button>
            <button style={{ ...S.btnPrimary, opacity: createProductLoading ? 0.6 : 1, cursor: createProductLoading ? 'not-allowed' : 'pointer' }} disabled={createProductLoading} onClick={handleCreateProduct}>
              {createProductLoading ? 'Creating…' : 'Create Product'}
            </button>
          </div>
        </div>
      </div>
    )}
    </>
  )
}
