-- Helper function that bypasses RLS to check if current user is admin
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true);
$$;

-- Drop policies that cause circular dependency
DROP POLICY IF EXISTS "admin_select_users" ON users;
DROP POLICY IF EXISTS "admin_update_users" ON users;
DROP POLICY IF EXISTS "admin_update_products" ON products;

-- Recreate using the SECURITY DEFINER helper
CREATE POLICY "admin_select_users" ON users
  FOR SELECT TO authenticated
  USING (is_admin() OR auth.uid() = id);

CREATE POLICY "admin_update_users" ON users
  FOR UPDATE TO authenticated
  USING (is_admin())
  WITH CHECK (is_admin());

CREATE POLICY "admin_update_products" ON products
  FOR UPDATE TO authenticated
  USING (is_admin())
  WITH CHECK (is_admin());

-- Allow authenticated users to read their own profile
CREATE POLICY "self_select_users" ON users
  FOR SELECT TO authenticated
  USING (auth.uid() = id);

-- Reload schema
NOTIFY pgrst, 'reload schema';
